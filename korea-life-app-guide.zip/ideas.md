# 한국 생활 앱 가이드 - 디자인 아이디어

## 앱 개요
외국인을 위한 한국 생활 필수 앱 사용 가이드. 다국어(한국어/영어) 지원, 카테고리별 탐색, 단계별 튜토리얼.

---

<response>
<text>
## 아이디어 A: "Seoul Metro" — 도시 정보 시스템 미학

**Design Movement**: 서울 지하철 노선도에서 영감받은 정보 디자인 + 현대 한국 도시 감성

**Core Principles**:
1. 컬러 코딩된 카테고리 시스템 (지하철 노선처럼 각 앱 카테고리에 고유 색상)
2. 명확한 정보 계층 구조 — 복잡한 정보를 단순하게
3. 모바일 우선 설계 (사용자가 스마트폰으로 참고할 것을 가정)
4. 다국어 전환이 자연스럽게 통합된 UI

**Color Philosophy**:
- 배경: 밝은 크림화이트 (#FAFAF8) — 종이 질감 느낌
- 주색: 코발트 블루 (#1B4FD8) — 신뢰와 안내
- 카테고리 색상: 오렌지(중고거래), 에메랄드(쇼핑), 바이올렛(생활서비스)
- 강조: 밝은 노랑 (#FFD600) — 중요 포인트 하이라이트

**Layout Paradigm**:
- 좌측 사이드바 네비게이션 (데스크탑) / 하단 탭바 (모바일)
- 카드 기반 앱 목록 — 각 카드에 앱 아이콘, 이름, 난이도 배지
- 튜토리얼은 세로 스크롤 스텝 형식 (각 단계가 스냅 포인트)

**Signature Elements**:
1. 지하철 노선도 스타일의 카테고리 연결선
2. 단계 번호를 원형 배지로 표시 (서울 지하철 역 번호 스타일)
3. 앱 난이도를 별점 대신 "쉬움/보통/어려움" 태그로 표시

**Interaction Philosophy**:
- 언어 전환 시 부드러운 페이드 트랜지션
- 튜토리얼 단계 완료 시 체크 애니메이션
- 카드 호버 시 살짝 들어올려지는 효과

**Animation**:
- 페이지 진입: 카드들이 아래에서 순차적으로 (stagger 60ms) 올라오는 효과
- 언어 전환: 200ms 크로스페이드
- 단계 완료: 초록 체크마크 스케일 인 (150ms)
- 버튼 클릭: scale(0.97) 100ms ease-out

**Typography System**:
- 헤딩: Noto Sans KR Bold (한국어) / Outfit Bold (영어)
- 본문: Noto Sans KR Regular / Inter Regular
- 단계 번호: Outfit Mono Bold
</text>
<probability>0.08</probability>
</response>

<response>
<text>
## 아이디어 B: "Hanok Digital" — 전통과 현대의 융합

**Design Movement**: 한옥의 기하학적 패턴 + 플랫 디지털 미니멀리즘

**Core Principles**:
1. 전통 단청 색상을 현대적으로 재해석한 팔레트
2. 비대칭 레이아웃 — 한옥 창살 패턴에서 영감받은 그리드
3. 여백을 적극 활용한 호흡감 있는 디자인
4. 정보는 단순하게, 시각적 임팩트는 강하게

**Color Philosophy**:
- 배경: 따뜻한 오프화이트 (#F5F0E8) — 한지 질감
- 주색: 단청 적색 (#C0392B) — 전통 한국 건축의 붉은색
- 보조색: 청록 (#2E86AB) — 단청의 청색
- 중성: 먹색 (#2C2C2C) — 먹물 느낌의 텍스트

**Layout Paradigm**:
- 메인 페이지: 비대칭 히어로 섹션 (좌측 큰 타이포, 우측 앱 카테고리 그리드)
- 카테고리 페이지: 마소리 타일 레이아웃 (다양한 크기의 카드)
- 튜토리얼: 타임라인 형식 (세로 중앙선 기준 좌우 교차 배치)

**Signature Elements**:
1. 한옥 창살 패턴을 SVG로 구현한 섹션 구분선
2. 앱 아이콘 주변에 전통 문양 테두리
3. 단계 번호를 한자 스타일 원형 인장으로 표현

**Interaction Philosophy**:
- 스크롤 시 요소들이 수묵화처럼 서서히 나타나는 효과
- 카드 선택 시 전통 도장 찍히는 느낌의 애니메이션

**Animation**:
- 페이지 진입: opacity 0→1 + translateY(20px→0) 300ms
- 카드 호버: 미묘한 그림자 깊이 변화
- 언어 전환: 슬라이드 전환 효과

**Typography System**:
- 헤딩: Noto Serif KR (한국어) / Playfair Display (영어)
- 본문: Noto Sans KR / Source Sans Pro
</text>
<probability>0.07</probability>
</response>

<response>
<text>
## 아이디어 C: "K-Guide" — 밝고 친근한 정보 가이드북

**Design Movement**: 현대 한국 앱 UI 감성 + 여행 가이드북 레이아웃

**Core Principles**:
1. 밝고 에너지 넘치는 색상으로 외국인에게 친근하게
2. 명확한 카테고리 색상 코딩으로 직관적 탐색
3. 스텝별 가이드를 실제 앱 스크린샷처럼 시각화
4. 영어/한국어 병기로 학습 효과 극대화

**Color Philosophy**:
- 배경: 순백 (#FFFFFF) + 연한 회색 섹션 (#F8F9FA)
- 주색: 생동감 있는 코랄 레드 (#FF4757) — 한국의 역동성
- 카테고리: 오렌지(중고거래 #FF6B35), 파랑(쇼핑 #3742FA), 초록(생활서비스 #2ED573)
- 강조: 골든 옐로우 (#FFA502) — 중요 정보 하이라이트

**Layout Paradigm**:
- 상단 고정 네비게이션 바 (언어 전환 버튼 포함)
- 히어로 섹션: 풀 와이드 배너 + 검색창 중앙 배치
- 카테고리 섹션: 3열 카드 그리드 (아이콘 + 이름 + 앱 수)
- 앱 상세: 좌측 목차 고정 + 우측 스크롤 콘텐츠

**Signature Elements**:
1. 각 앱에 실제 앱 아이콘 스타일의 둥근 아이콘 (컬러 그라디언트)
2. 튜토리얼 단계에 모바일 폰 프레임 목업
3. 진행률 표시 바 (튜토리얼 상단)

**Interaction Philosophy**:
- 검색 시 실시간 필터링 (debounce 300ms)
- 튜토리얼 단계 완료 시 confetti 효과 (선택적)
- 스크롤 진행률 표시

**Animation**:
- 카드 진입: 아래에서 위로 stagger 50ms
- 검색 결과: 부드러운 필터 애니메이션
- 단계 전환: 슬라이드 인/아웃 200ms

**Typography System**:
- 헤딩: Outfit ExtraBold (영어) / Noto Sans KR Black (한국어)
- 본문: Outfit Regular / Noto Sans KR Regular
- 코드/단계: JetBrains Mono
</text>
<probability>0.09</probability>
</response>

---

## 선택된 디자인: 아이디어 A — "Seoul Metro"

**이유**: 외국인 사용자가 복잡한 한국 앱을 배우는 목적에 가장 적합. 지하철 노선도처럼 명확한 색상 코딩과 정보 계층이 직관적 탐색을 돕고, 모바일 우선 설계가 실제 사용 상황(앱 사용 중 참고)에 최적화됨.
