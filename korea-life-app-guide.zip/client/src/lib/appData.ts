// Korea Life App Guide - App Data
// Design: "Seoul Metro" - Color-coded categories, step-by-step tutorials

export type Language = "ko" | "en";

export interface AppStep {
  id: number;
  titleKo: string;
  titleEn: string;
  descriptionKo: string;
  descriptionEn: string;
  tip?: { ko: string; en: string };
}

export interface AppGuide {
  id: string;
  nameKo: string;
  nameEn: string;
  descriptionKo: string;
  descriptionEn: string;
  icon: string;
  color: string;
  difficulty: "easy" | "medium" | "hard";
  categoryId: string;
  features: { ko: string; en: string }[];
  steps: AppStep[];
  faqs: { questionKo: string; questionEn: string; answerKo: string; answerEn: string }[];
}

export interface Category {
  id: string;
  nameKo: string;
  nameEn: string;
  descriptionKo: string;
  descriptionEn: string;
  color: string;
  bgColor: string;
  icon: string;
  image: string;
  apps: string[];
}

export const categories: Category[] = [
  {
    id: "secondhand",
    nameKo: "중고거래",
    nameEn: "Secondhand",
    descriptionKo: "중고 물품을 사고팔 수 있는 앱들",
    descriptionEn: "Apps for buying and selling used items",
    color: "#E8621A",
    bgColor: "#FFF4ED",
    icon: "🔄",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663670945450/LSqMnGR6udQiFU7R9ESGnE/category-secondhand-NgPQbhhF63ejwxEktspEBz.webp",
    apps: ["karrot", "junggo"],
  },
  {
    id: "shopping",
    nameKo: "쇼핑",
    nameEn: "Shopping",
    descriptionKo: "온라인 쇼핑 앱들",
    descriptionEn: "Online shopping apps",
    color: "#0F7A4E",
    bgColor: "#EDFAF3",
    icon: "🛍️",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663670945450/LSqMnGR6udQiFU7R9ESGnE/category-shopping-8j4nECW9nXH2EVeC5iH45d.webp",
    apps: ["coupang", "gmarket", "ably"],
  },
  {
    id: "life",
    nameKo: "생활 서비스",
    nameEn: "Life Services",
    descriptionKo: "배달, 교통, 예약 등 생활 필수 앱들",
    descriptionEn: "Delivery, transport, reservation apps",
    color: "#6B21A8",
    bgColor: "#F5F0FF",
    icon: "🏙️",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663670945450/LSqMnGR6udQiFU7R9ESGnE/category-life-3C5VfEbYNVej3jo2J9higq.webp",
    apps: ["baemin", "kakaomap", "kakaotaxi"],
  },
];

export const appGuides: AppGuide[] = [
  // ===== 중고거래 =====
  {
    id: "karrot",
    nameKo: "당근마켓",
    nameEn: "Karrot Market",
    descriptionKo: "동네 이웃과 중고 물품을 직거래하는 앱",
    descriptionEn: "Local secondhand marketplace app",
    icon: "🥕",
    color: "#E8621A",
    difficulty: "easy",
    categoryId: "secondhand",
    features: [
      { ko: "동네 기반 직거래", en: "Local direct trade" },
      { ko: "채팅으로 흥정", en: "Chat negotiation" },
      { ko: "매너 온도 시스템", en: "Manner temperature system" },
      { ko: "무료 나눔", en: "Free sharing" },
    ],
    steps: [
      {
        id: 1,
        titleKo: "앱 설치 및 회원가입",
        titleEn: "Install & Sign Up",
        descriptionKo: "App Store 또는 Google Play에서 '당근마켓'을 검색하여 설치합니다. 앱을 열면 휴대폰 번호로 인증 후 회원가입을 진행합니다.",
        descriptionEn: "Search '당근마켓' or 'Karrot' on App Store or Google Play and install. Open the app and sign up with your phone number.",
        tip: { ko: "한국 휴대폰 번호가 필요합니다. 외국 번호도 일부 지원됩니다.", en: "A Korean phone number is required. Some foreign numbers are also supported." },
      },
      {
        id: 2,
        titleKo: "동네 인증하기",
        titleEn: "Verify Your Neighborhood",
        descriptionKo: "앱에서 '동네 인증' 버튼을 누르고 현재 위치를 허용합니다. 내 위치 기반으로 동네가 자동 설정됩니다. 최대 2개 동네를 등록할 수 있습니다.",
        descriptionEn: "Tap '동네 인증' (Neighborhood Verification) and allow location access. Your neighborhood is set automatically. You can register up to 2 neighborhoods.",
        tip: { ko: "GPS를 켜두면 더 정확한 동네 인증이 가능합니다.", en: "Keep GPS on for more accurate neighborhood verification." },
      },
      {
        id: 3,
        titleKo: "상품 검색하기",
        titleEn: "Search for Items",
        descriptionKo: "홈 화면 상단의 검색창에 원하는 물품을 입력합니다. 예: '아이폰', '책상', '자전거'. 가격 필터와 카테고리 필터를 활용하면 더 쉽게 찾을 수 있습니다.",
        descriptionEn: "Enter the item you want in the search bar at the top of the home screen. E.g., 'iPhone', '책상 (desk)', '자전거 (bicycle)'. Use price and category filters for better results.",
      },
      {
        id: 4,
        titleKo: "판매자에게 채팅 보내기",
        titleEn: "Chat with the Seller",
        descriptionKo: "마음에 드는 상품을 찾으면 '채팅하기' 버튼을 누릅니다. 가격 협상이나 거래 장소를 채팅으로 정합니다. '얼마에 팔아요?' 또는 'How much?' 라고 물어볼 수 있습니다.",
        descriptionEn: "When you find an item you like, tap '채팅하기' (Chat). Negotiate the price and meeting place via chat. You can ask '얼마에 팔아요?' or 'How much?'",
        tip: { ko: "거래 전 상품 상태를 사진으로 더 보내달라고 요청하세요.", en: "Before trading, ask the seller to send more photos of the item's condition." },
      },
      {
        id: 5,
        titleKo: "직거래 완료 및 후기 남기기",
        titleEn: "Complete Trade & Leave Review",
        descriptionKo: "약속 장소에서 물건을 확인하고 거래를 완료합니다. 거래 후 앱에서 '거래 완료' 버튼을 누르고 상대방에게 매너 평가를 남겨주세요.",
        descriptionEn: "Meet at the agreed location, check the item, and complete the trade. After trading, tap '거래 완료' (Trade Complete) and leave a manner rating for the other person.",
      },
    ],
    faqs: [
      {
        questionKo: "당근마켓에서 사기를 당하면 어떻게 하나요?",
        questionEn: "What should I do if I get scammed on Karrot?",
        answerKo: "앱 내 '신고하기' 기능을 사용하거나, 고객센터(1:1 문의)에 연락하세요. 직거래 시 공공장소에서 만나고, 물건을 확인 후 결제하는 것을 권장합니다.",
        answerEn: "Use the '신고하기' (Report) feature in the app or contact customer service. For in-person trades, meet in public places and verify the item before paying.",
      },
      {
        questionKo: "가격 흥정은 어떻게 하나요?",
        questionEn: "How do I negotiate the price?",
        answerKo: "채팅에서 '네고 가능한가요?' 또는 '조금 깎아주실 수 있나요?'라고 물어보세요. 영어로는 'Can you lower the price a bit?'라고 해도 됩니다.",
        answerEn: "In chat, ask '네고 가능한가요?' (Is negotiation possible?) or '조금 깎아주실 수 있나요?' (Can you lower the price a bit?)",
      },
      {
        questionKo: "매너 온도가 무엇인가요?",
        questionEn: "What is the Manner Temperature?",
        answerKo: "매너 온도는 거래 후 상대방이 남기는 평가로 결정되는 신뢰 지수입니다. 36.5°C에서 시작하며, 좋은 거래를 많이 할수록 올라갑니다.",
        answerEn: "Manner Temperature is a trust score determined by ratings left after trades. It starts at 36.5°C and goes up with more positive trades.",
      },
    ],
  },
  {
    id: "junggo",
    nameKo: "중고나라",
    nameEn: "Junggo Nara",
    descriptionKo: "전국 규모의 중고 거래 커뮤니티 앱",
    descriptionEn: "Nationwide secondhand trading community app",
    icon: "♻️",
    color: "#E8621A",
    difficulty: "medium",
    categoryId: "secondhand",
    features: [
      { ko: "전국 거래 가능", en: "Nationwide trading" },
      { ko: "택배 거래 지원", en: "Delivery trading support" },
      { ko: "안전결제 시스템", en: "Safe payment system" },
      { ko: "카테고리별 검색", en: "Category-based search" },
    ],
    steps: [
      {
        id: 1,
        titleKo: "앱 설치 및 회원가입",
        titleEn: "Install & Sign Up",
        descriptionKo: "앱 스토어에서 '중고나라'를 검색하여 설치합니다. 카카오, 네이버, 구글 계정으로 간편 로그인이 가능합니다.",
        descriptionEn: "Search '중고나라' on the app store and install. You can log in easily with Kakao, Naver, or Google accounts.",
      },
      {
        id: 2,
        titleKo: "원하는 상품 검색",
        titleEn: "Search for Items",
        descriptionKo: "검색창에 원하는 물품을 입력합니다. 지역, 가격대, 상품 상태(새상품/중고) 필터를 활용하세요.",
        descriptionEn: "Enter the item you want in the search bar. Use filters for region, price range, and item condition (new/used).",
      },
      {
        id: 3,
        titleKo: "안전결제로 구매하기",
        titleEn: "Purchase with Safe Payment",
        descriptionKo: "'안전결제' 버튼을 이용하면 물건을 받은 후 판매자에게 돈이 지급되어 사기를 방지할 수 있습니다. 카드, 계좌이체 등 다양한 결제 수단을 지원합니다.",
        descriptionEn: "Using '안전결제' (Safe Payment) means money is released to the seller only after you receive the item. Supports cards, bank transfer, and more.",
        tip: { ko: "직거래보다 안전결제를 이용하면 사기 피해를 예방할 수 있습니다.", en: "Using Safe Payment instead of direct trade helps prevent fraud." },
      },
    ],
    faqs: [
      {
        questionKo: "택배 거래는 어떻게 하나요?",
        questionEn: "How does delivery trading work?",
        answerKo: "판매자와 채팅으로 택배 거래를 합의하고, 안전결제를 이용하세요. 판매자가 택배를 보내면 운송장 번호를 받아 배송 추적이 가능합니다.",
        answerEn: "Agree on delivery trading with the seller via chat and use Safe Payment. Once the seller ships, you'll receive a tracking number.",
      },
    ],
  },

  // ===== 쇼핑 =====
  {
    id: "coupang",
    nameKo: "쿠팡",
    nameEn: "Coupang",
    descriptionKo: "로켓배송으로 유명한 한국 최대 이커머스 앱",
    descriptionEn: "Korea's largest e-commerce app famous for Rocket Delivery",
    icon: "🚀",
    color: "#0F7A4E",
    difficulty: "easy",
    categoryId: "shopping",
    features: [
      { ko: "로켓배송 (당일/익일)", en: "Rocket Delivery (same/next day)" },
      { ko: "로켓프레시 (신선식품)", en: "Rocket Fresh (fresh food)" },
      { ko: "쿠팡이츠 (음식 배달)", en: "Coupang Eats (food delivery)" },
      { ko: "쿠팡플레이 (OTT)", en: "Coupang Play (streaming)" },
    ],
    steps: [
      {
        id: 1,
        titleKo: "앱 설치 및 회원가입",
        titleEn: "Install & Sign Up",
        descriptionKo: "앱 스토어에서 '쿠팡'을 검색하여 설치합니다. 이메일 또는 휴대폰 번호로 회원가입을 진행합니다. 외국인도 가입 가능합니다.",
        descriptionEn: "Search 'Coupang' on the app store and install. Sign up with email or phone number. Foreigners can also sign up.",
      },
      {
        id: 2,
        titleKo: "상품 검색하기",
        titleEn: "Search for Products",
        descriptionKo: "홈 화면 상단 검색창에 원하는 상품을 입력합니다. 한국어로 검색하면 더 많은 결과가 나옵니다. '로켓배송' 필터를 선택하면 빠른 배송 상품만 볼 수 있습니다.",
        descriptionEn: "Enter the product you want in the search bar. Searching in Korean gives more results. Select '로켓배송' filter to see only fast delivery items.",
        tip: { ko: "영어로 검색해도 되지만, 한국어로 검색하면 더 많은 상품이 나옵니다.", en: "You can search in English, but searching in Korean shows more products." },
      },
      {
        id: 3,
        titleKo: "상품 선택 및 옵션 설정",
        titleEn: "Select Product & Options",
        descriptionKo: "원하는 상품을 탭하여 상세 페이지로 이동합니다. 색상, 사이즈 등 옵션을 선택합니다. 상품 리뷰와 별점을 꼭 확인하세요.",
        descriptionEn: "Tap the product to go to the detail page. Select options like color and size. Make sure to check product reviews and ratings.",
      },
      {
        id: 4,
        titleKo: "장바구니 및 결제",
        titleEn: "Cart & Payment",
        descriptionKo: "'장바구니 담기' 또는 '바로 구매' 버튼을 누릅니다. 배송지 주소를 입력하고 결제 수단을 선택합니다. 신용카드, 체크카드, 카카오페이, 네이버페이 등을 사용할 수 있습니다.",
        descriptionEn: "Tap '장바구니 담기' (Add to Cart) or '바로 구매' (Buy Now). Enter your delivery address and select payment method. You can use credit card, debit card, KakaoPay, NaverPay, etc.",
        tip: { ko: "외국 카드도 대부분 사용 가능합니다. 결제 시 '해외카드'를 선택하세요.", en: "Most foreign cards work. Select '해외카드' (Foreign Card) when paying." },
      },
      {
        id: 5,
        titleKo: "배송 추적하기",
        titleEn: "Track Delivery",
        descriptionKo: "'마이쿠팡' → '주문내역'에서 배송 상태를 확인할 수 있습니다. 로켓배송은 보통 당일 또는 익일 배송됩니다.",
        descriptionEn: "Check delivery status in 'My Coupang' → 'Order History'. Rocket Delivery usually arrives same day or next day.",
      },
    ],
    faqs: [
      {
        questionKo: "로켓배송이란 무엇인가요?",
        questionEn: "What is Rocket Delivery?",
        answerKo: "쿠팡이 직접 관리하는 빠른 배송 서비스입니다. 오후 12시 이전 주문 시 당일 배송, 그 이후는 익일 배송이 가능합니다.",
        answerEn: "Rocket Delivery is Coupang's own fast delivery service. Orders placed before noon get same-day delivery; orders after noon get next-day delivery.",
      },
      {
        questionKo: "반품은 어떻게 하나요?",
        questionEn: "How do I return an item?",
        answerKo: "'마이쿠팡' → '주문내역' → 해당 상품 → '반품 신청'을 누르세요. 로켓배송 상품은 무료 반품이 가능합니다.",
        answerEn: "Go to 'My Coupang' → 'Order History' → select item → '반품 신청' (Request Return). Rocket Delivery items can be returned for free.",
      },
      {
        questionKo: "쿠팡에서 외국 카드로 결제할 수 있나요?",
        questionEn: "Can I pay with a foreign card on Coupang?",
        answerKo: "Visa, Mastercard 등 해외 카드로 결제 가능합니다. 결제 시 '해외카드'를 선택하세요.",
        answerEn: "You can pay with foreign cards like Visa and Mastercard. Select '해외카드' (Foreign Card) during checkout.",
      },
    ],
  },
  {
    id: "gmarket",
    nameKo: "G마켓",
    nameEn: "G-Market",
    descriptionKo: "다양한 판매자의 상품을 비교하며 구매하는 오픈마켓",
    descriptionEn: "Open marketplace to compare and buy from various sellers",
    icon: "🛒",
    color: "#0F7A4E",
    difficulty: "medium",
    categoryId: "shopping",
    features: [
      { ko: "스마일클럽 멤버십", en: "Smile Club membership" },
      { ko: "스마일페이 간편결제", en: "SmilePay easy payment" },
      { ko: "다양한 할인 쿠폰", en: "Various discount coupons" },
      { ko: "글로벌 배송 지원", en: "Global shipping support" },
    ],
    steps: [
      {
        id: 1,
        titleKo: "앱 설치 및 회원가입",
        titleEn: "Install & Sign Up",
        descriptionKo: "앱 스토어에서 'G마켓'을 검색하여 설치합니다. 이메일로 회원가입하거나 소셜 로그인을 이용합니다.",
        descriptionEn: "Search 'G-Market' on the app store and install. Sign up with email or use social login.",
      },
      {
        id: 2,
        titleKo: "상품 검색 및 비교",
        titleEn: "Search & Compare Products",
        descriptionKo: "검색창에 상품명을 입력합니다. 같은 상품을 여러 판매자가 판매하므로 가격과 리뷰를 비교하세요. '최저가순' 정렬을 활용하면 저렴한 상품을 찾을 수 있습니다.",
        descriptionEn: "Enter the product name in the search bar. Multiple sellers sell the same product, so compare prices and reviews. Use '최저가순' (Lowest Price) sort to find cheaper items.",
      },
      {
        id: 3,
        titleKo: "쿠폰 적용 및 결제",
        titleEn: "Apply Coupon & Pay",
        descriptionKo: "결제 전 '쿠폰 적용' 버튼을 눌러 할인 쿠폰을 적용하세요. 스마일페이, 카드, 계좌이체 등으로 결제할 수 있습니다.",
        descriptionEn: "Before paying, tap '쿠폰 적용' (Apply Coupon) to use discount coupons. Pay with SmilePay, card, bank transfer, etc.",
        tip: { ko: "첫 구매 쿠폰을 꼭 활용하세요! 상당한 할인을 받을 수 있습니다.", en: "Make sure to use the first-purchase coupon! You can get significant discounts." },
      },
    ],
    faqs: [
      {
        questionKo: "스마일클럽이란 무엇인가요?",
        questionEn: "What is Smile Club?",
        answerKo: "G마켓의 유료 멤버십 서비스입니다. 월 구독료를 내면 추가 할인, 무료 배송 혜택 등을 받을 수 있습니다.",
        answerEn: "Smile Club is G-Market's paid membership service. Pay a monthly fee to get extra discounts, free shipping benefits, and more.",
      },
    ],
  },
  {
    id: "ably",
    nameKo: "에이블리",
    nameEn: "Ably",
    descriptionKo: "한국 패션 쇼핑 전문 앱",
    descriptionEn: "Korean fashion shopping app",
    icon: "👗",
    color: "#0F7A4E",
    difficulty: "easy",
    categoryId: "shopping",
    features: [
      { ko: "한국 트렌드 패션", en: "Korean trend fashion" },
      { ko: "사이즈 가이드", en: "Size guide" },
      { ko: "스타일 추천", en: "Style recommendations" },
      { ko: "빠른 배송", en: "Fast delivery" },
    ],
    steps: [
      {
        id: 1,
        titleKo: "앱 설치 및 회원가입",
        titleEn: "Install & Sign Up",
        descriptionKo: "앱 스토어에서 '에이블리'를 검색하여 설치합니다. 카카오, 네이버 계정으로 간편 로그인이 가능합니다.",
        descriptionEn: "Search 'Ably' on the app store and install. Easy login with Kakao or Naver accounts.",
      },
      {
        id: 2,
        titleKo: "스타일 탐색하기",
        titleEn: "Browse Styles",
        descriptionKo: "홈 화면에서 트렌딩 스타일을 확인하거나, 카테고리(상의, 하의, 원피스 등)를 선택하여 탐색합니다. 마음에 드는 상품은 하트 버튼으로 찜할 수 있습니다.",
        descriptionEn: "Check trending styles on the home screen or browse by category (tops, bottoms, dresses, etc.). Tap the heart button to save items you like.",
      },
      {
        id: 3,
        titleKo: "사이즈 선택 및 구매",
        titleEn: "Select Size & Purchase",
        descriptionKo: "상품 상세 페이지에서 사이즈 가이드를 참고하여 사이즈를 선택합니다. 한국 사이즈(S/M/L 또는 44/55/66)를 확인하세요.",
        descriptionEn: "On the product detail page, refer to the size guide and select your size. Check Korean sizes (S/M/L or 44/55/66).",
        tip: { ko: "한국 사이즈는 국제 사이즈와 다를 수 있습니다. 사이즈 가이드를 꼭 확인하세요.", en: "Korean sizes may differ from international sizes. Always check the size guide." },
      },
    ],
    faqs: [
      {
        questionKo: "한국 사이즈 44, 55, 66이 무엇인가요?",
        questionEn: "What are Korean sizes 44, 55, 66?",
        answerKo: "한국 여성복 사이즈 표기입니다. 44=XS/S, 55=S/M, 66=M/L, 77=L/XL에 해당합니다. 브랜드마다 다를 수 있으니 사이즈 가이드를 확인하세요.",
        answerEn: "These are Korean women's clothing size notations. 44=XS/S, 55=S/M, 66=M/L, 77=L/XL. May vary by brand, so check the size guide.",
      },
    ],
  },

  // ===== 생활 서비스 =====
  {
    id: "baemin",
    nameKo: "배달의민족",
    nameEn: "Baemin",
    descriptionKo: "한국 최대 음식 배달 앱",
    descriptionEn: "Korea's largest food delivery app",
    icon: "🍜",
    color: "#6B21A8",
    difficulty: "easy",
    categoryId: "life",
    features: [
      { ko: "음식 배달 주문", en: "Food delivery order" },
      { ko: "포장 주문", en: "Takeout order" },
      { ko: "배민1 빠른배달", en: "Baemin1 fast delivery" },
      { ko: "다양한 쿠폰/할인", en: "Various coupons/discounts" },
    ],
    steps: [
      {
        id: 1,
        titleKo: "앱 설치 및 회원가입",
        titleEn: "Install & Sign Up",
        descriptionKo: "앱 스토어에서 '배달의민족'을 검색하여 설치합니다. 휴대폰 번호로 회원가입을 진행합니다.",
        descriptionEn: "Search '배달의민족' or 'Baemin' on the app store and install. Sign up with your phone number.",
      },
      {
        id: 2,
        titleKo: "배달 주소 설정",
        titleEn: "Set Delivery Address",
        descriptionKo: "앱 상단의 주소 버튼을 누르고 배달 받을 주소를 입력합니다. 도로명 주소 또는 지번 주소를 입력하세요. 상세 주소(동/호수)도 꼭 입력하세요.",
        descriptionEn: "Tap the address button at the top and enter your delivery address. Enter the road name address or lot number address. Don't forget to enter the detailed address (unit/floor number).",
        tip: { ko: "영어 주소 입력이 어려우면 네이버 지도에서 주소를 복사해서 붙여넣기 하세요.", en: "If entering an English address is difficult, copy and paste the address from Naver Maps." },
      },
      {
        id: 3,
        titleKo: "음식점 선택하기",
        titleEn: "Select a Restaurant",
        descriptionKo: "카테고리(치킨, 피자, 한식 등)를 선택하거나 검색창에 음식 종류를 입력합니다. 별점, 리뷰 수, 최소 주문 금액을 확인하세요.",
        descriptionEn: "Select a category (chicken, pizza, Korean food, etc.) or enter the food type in the search bar. Check ratings, number of reviews, and minimum order amount.",
      },
      {
        id: 4,
        titleKo: "메뉴 선택 및 주문",
        titleEn: "Select Menu & Order",
        descriptionKo: "원하는 메뉴를 선택하고 수량을 조절합니다. 옵션(맵기 조절, 추가 토핑 등)을 선택합니다. '주문하기' 버튼을 눌러 결제를 진행합니다.",
        descriptionEn: "Select the menu items you want and adjust quantities. Choose options (spice level, extra toppings, etc.). Tap '주문하기' (Order) to proceed to payment.",
      },
      {
        id: 5,
        titleKo: "배달 추적하기",
        titleEn: "Track Delivery",
        descriptionKo: "주문 후 실시간으로 배달 현황을 확인할 수 있습니다. '주문 확인' → '배달 현황'에서 라이더의 위치를 지도로 볼 수 있습니다.",
        descriptionEn: "After ordering, you can track the delivery in real-time. In 'Order Confirmation' → 'Delivery Status', you can see the rider's location on a map.",
      },
    ],
    faqs: [
      {
        questionKo: "최소 주문 금액이 있나요?",
        questionEn: "Is there a minimum order amount?",
        answerKo: "대부분의 음식점에 최소 주문 금액이 있습니다. 보통 10,000원~15,000원입니다. 음식점 페이지에서 확인할 수 있습니다.",
        answerEn: "Most restaurants have a minimum order amount, usually 10,000-15,000 won. You can check on the restaurant's page.",
      },
      {
        questionKo: "배달비는 얼마인가요?",
        questionEn: "How much is the delivery fee?",
        answerKo: "배달비는 음식점과 거리에 따라 다릅니다. 보통 2,000원~5,000원이며, 일부 음식점은 무료 배달을 제공합니다.",
        answerEn: "Delivery fees vary by restaurant and distance. Usually 2,000-5,000 won, and some restaurants offer free delivery.",
      },
      {
        questionKo: "영어 메뉴가 있나요?",
        questionEn: "Are there English menus?",
        answerKo: "대부분의 메뉴는 한국어로만 제공됩니다. 구글 번역기 앱을 사용하여 메뉴를 번역하거나, 사진 번역 기능을 활용하세요.",
        answerEn: "Most menus are in Korean only. Use the Google Translate app to translate menus, or use the photo translation feature.",
      },
    ],
  },
  {
    id: "kakaomap",
    nameKo: "카카오맵",
    nameEn: "Kakao Maps",
    descriptionKo: "한국에서 가장 많이 사용하는 지도 앱",
    descriptionEn: "The most used map app in Korea",
    icon: "🗺️",
    color: "#6B21A8",
    difficulty: "easy",
    categoryId: "life",
    features: [
      { ko: "대중교통 길찾기", en: "Public transit navigation" },
      { ko: "도보/자전거 경로", en: "Walking/cycling routes" },
      { ko: "주변 맛집 검색", en: "Nearby restaurant search" },
      { ko: "실시간 교통 정보", en: "Real-time traffic info" },
    ],
    steps: [
      {
        id: 1,
        titleKo: "앱 설치 및 설정",
        titleEn: "Install & Setup",
        descriptionKo: "앱 스토어에서 '카카오맵'을 검색하여 설치합니다. 위치 권한을 허용하면 현재 위치 기반 서비스를 이용할 수 있습니다.",
        descriptionEn: "Search 'Kakao Maps' on the app store and install. Allow location permission to use location-based services.",
      },
      {
        id: 2,
        titleKo: "목적지 검색하기",
        titleEn: "Search Destination",
        descriptionKo: "검색창에 목적지를 입력합니다. 한국어 또는 영어로 검색 가능합니다. 예: '경복궁', 'Gyeongbokgung', '강남역'",
        descriptionEn: "Enter your destination in the search bar. You can search in Korean or English. E.g., '경복궁', 'Gyeongbokgung', '강남역'",
      },
      {
        id: 3,
        titleKo: "길찾기 이용하기",
        titleEn: "Use Navigation",
        descriptionKo: "'길찾기' 버튼을 누르고 이동 수단을 선택합니다. 대중교통(지하철+버스), 자동차, 도보, 자전거 중 선택하세요. 대중교통 경로에서 환승 정보와 소요 시간을 확인할 수 있습니다.",
        descriptionEn: "Tap '길찾기' (Navigation) and select your transportation mode. Choose from public transit (subway+bus), car, walking, or cycling. For public transit, you can see transfer info and travel time.",
        tip: { ko: "지하철 이용 시 '지하철 노선도' 탭에서 노선을 미리 확인하세요.", en: "When using the subway, check the route in the '지하철 노선도' (Subway Map) tab." },
      },
    ],
    faqs: [
      {
        questionKo: "영어로도 사용할 수 있나요?",
        questionEn: "Can I use it in English?",
        answerKo: "카카오맵은 주로 한국어로 제공됩니다. 영어 검색은 가능하지만 UI는 한국어입니다. 영어 지원이 더 좋은 '네이버 지도' 또는 'Google Maps'도 한국에서 잘 작동합니다.",
        answerEn: "Kakao Maps is primarily in Korean. English search is possible but the UI is in Korean. '네이버 지도' (Naver Maps) or Google Maps also work well in Korea with better English support.",
      },
    ],
  },
  {
    id: "kakaotaxi",
    nameKo: "카카오T",
    nameEn: "Kakao T",
    descriptionKo: "택시, 대리운전, 주차 등 교통 서비스 앱",
    descriptionEn: "Transportation service app for taxi, designated driver, parking",
    icon: "🚕",
    color: "#6B21A8",
    difficulty: "easy",
    categoryId: "life",
    features: [
      { ko: "택시 호출", en: "Taxi booking" },
      { ko: "카풀 서비스", en: "Carpool service" },
      { ko: "대리운전", en: "Designated driver" },
      { ko: "주차장 예약", en: "Parking reservation" },
    ],
    steps: [
      {
        id: 1,
        titleKo: "앱 설치 및 회원가입",
        titleEn: "Install & Sign Up",
        descriptionKo: "앱 스토어에서 '카카오T'를 검색하여 설치합니다. 카카오 계정 또는 휴대폰 번호로 가입합니다.",
        descriptionEn: "Search 'Kakao T' on the app store and install. Sign up with a Kakao account or phone number.",
      },
      {
        id: 2,
        titleKo: "택시 호출하기",
        titleEn: "Call a Taxi",
        descriptionKo: "홈 화면에서 '택시' 버튼을 누릅니다. 현재 위치가 자동으로 출발지로 설정됩니다. 목적지를 입력하고 '일반택시' 또는 '블랙(고급택시)'를 선택합니다.",
        descriptionEn: "Tap the '택시' (Taxi) button on the home screen. Your current location is automatically set as the starting point. Enter your destination and choose '일반택시' (Regular Taxi) or '블랙' (Premium Taxi).",
      },
      {
        id: 3,
        titleKo: "결제 및 탑승",
        titleEn: "Payment & Boarding",
        descriptionKo: "기사가 배정되면 차량 정보와 예상 도착 시간이 표시됩니다. 탑승 후 목적지까지 이동합니다. 현금 또는 카드로 결제하거나, 앱 내 카카오페이로 결제할 수 있습니다.",
        descriptionEn: "Once a driver is assigned, vehicle info and estimated arrival time are shown. Board the taxi and travel to your destination. Pay with cash, card, or KakaoPay within the app.",
        tip: { ko: "목적지를 미리 앱에 입력하면 기사에게 한국어로 말하지 않아도 됩니다.", en: "Enter your destination in the app beforehand so you don't need to speak Korean to the driver." },
      },
    ],
    faqs: [
      {
        questionKo: "외국인도 카카오T를 사용할 수 있나요?",
        questionEn: "Can foreigners use Kakao T?",
        answerKo: "네, 외국인도 사용 가능합니다. 외국 카드로 결제도 가능합니다. 앱 내에서 목적지를 설정하면 기사에게 한국어로 말할 필요가 없어 편리합니다.",
        answerEn: "Yes, foreigners can use it. Foreign cards are also accepted. Setting the destination in the app means you don't need to speak Korean to the driver.",
      },
      {
        questionKo: "택시 요금은 얼마인가요?",
        questionEn: "How much does a taxi cost?",
        answerKo: "기본요금은 4,800원(일반택시 기준)이며, 거리와 시간에 따라 추가됩니다. 심야(자정~오전 4시)에는 할증 요금이 적용됩니다.",
        answerEn: "The base fare is 4,800 won (regular taxi), with additional charges based on distance and time. Late night surcharges apply from midnight to 4 AM.",
      },
    ],
  },
];

export function getAppById(id: string): AppGuide | undefined {
  return appGuides.find((app) => app.id === id);
}

export function getCategoryById(id: string): Category | undefined {
  return categories.find((cat) => cat.id === id);
}

export function getAppsByCategory(categoryId: string): AppGuide[] {
  return appGuides.filter((app) => app.categoryId === categoryId);
}

export function searchApps(query: string): AppGuide[] {
  const q = query.toLowerCase();
  return appGuides.filter(
    (app) =>
      app.nameKo.toLowerCase().includes(q) ||
      app.nameEn.toLowerCase().includes(q) ||
      app.descriptionKo.toLowerCase().includes(q) ||
      app.descriptionEn.toLowerCase().includes(q)
  );
}

export function getDifficultyLabel(difficulty: AppGuide["difficulty"], lang: Language) {
  const labels = {
    easy: { ko: "쉬움", en: "Easy" },
    medium: { ko: "보통", en: "Medium" },
    hard: { ko: "어려움", en: "Hard" },
  };
  return labels[difficulty][lang];
}

export function getDifficultyColor(difficulty: AppGuide["difficulty"]) {
  return {
    easy: "text-emerald-600 bg-emerald-50",
    medium: "text-amber-600 bg-amber-50",
    hard: "text-red-600 bg-red-50",
  }[difficulty];
}
