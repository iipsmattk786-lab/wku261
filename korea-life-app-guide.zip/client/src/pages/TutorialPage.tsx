// Seoul Metro Design - Tutorial Page
// Interactive step-by-step tutorial with progress tracking

import { useState } from "react";
import { Link, useParams, useLocation } from "wouter";
import { ArrowLeft, ArrowRight, CheckCircle2, Circle, Home, RotateCcw, Trophy } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { getAppById, getCategoryById } from "@/lib/appData";
import Navbar from "@/components/Navbar";

export default function TutorialPage() {
  const { id } = useParams<{ id: string }>();
  const { lang, t } = useLanguage();
  const [, navigate] = useLocation();
  const app = getAppById(id);
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<Set<number>>(new Set());
  const [finished, setFinished] = useState(false);

  if (!app) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-20 text-center">
          <p className="text-muted-foreground">{t("앱 가이드를 찾을 수 없습니다.", "App guide not found.")}</p>
          <Link href="/">
            <button className="mt-4 text-primary hover:underline">{t("홈으로 돌아가기", "Go back home")}</button>
          </Link>
        </div>
      </div>
    );
  }

  const category = getCategoryById(app.categoryId);
  const step = app.steps[currentStep];
  const isLastStep = currentStep === app.steps.length - 1;
  const progress = ((completedSteps.size) / app.steps.length) * 100;

  const handleNext = () => {
    setCompletedSteps((prev) => { const next = new Set(prev); next.add(currentStep); return next; });
    if (isLastStep) {
      setFinished(true);
    } else {
      setCurrentStep((prev) => prev + 1);
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep((prev) => prev - 1);
    }
  };

  const handleRestart = () => {
    setCurrentStep(0);
    setCompletedSteps(new Set());
    setFinished(false);
  };

  // Completion screen
  if (finished) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-20 flex flex-col items-center text-center max-w-lg mx-auto">
          <div
            className="w-24 h-24 rounded-full flex items-center justify-center text-5xl mb-6 shadow-lg"
            style={{ backgroundColor: category?.bgColor }}
          >
            <Trophy className="w-12 h-12" style={{ color: category?.color }} />
          </div>
          <h1 className="text-4xl font-extrabold text-foreground mb-3" style={{ fontFamily: 'Outfit, sans-serif' }}>
            {t("완료!", "Complete!")}
          </h1>
          <p className="text-xl text-muted-foreground mb-2">
            {lang === "ko" ? app.nameKo : app.nameEn}
          </p>
          <p className="text-muted-foreground mb-8">
            {t(
              `${app.steps.length}개 단계를 모두 완료했습니다! 이제 앱을 사용할 준비가 되었습니다.`,
              `You've completed all ${app.steps.length} steps! You're now ready to use the app.`
            )}
          </p>

          <div className="flex flex-col sm:flex-row gap-4 w-full">
            <button
              onClick={handleRestart}
              className="flex items-center justify-center gap-2 px-6 py-3 rounded-xl border-2 font-semibold text-foreground hover:bg-muted transition-colors"
              style={{ borderColor: category?.color + "40" }}
            >
              <RotateCcw className="w-4 h-4" />
              {t("다시 보기", "Review Again")}
            </button>
            <Link href={`/category/${app.categoryId}`}>
              <button
                className="flex-1 flex items-center justify-center gap-2 px-6 py-3 rounded-xl text-white font-semibold transition-all hover:opacity-90"
                style={{ backgroundColor: category?.color }}
              >
                {t("다른 앱 보기", "See Other Apps")}
                <ArrowRight className="w-4 h-4" />
              </button>
            </Link>
          </div>

          <Link href="/">
            <button className="mt-4 flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
              <Home className="w-4 h-4" />
              {t("홈으로", "Back to Home")}
            </button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />

      {/* Tutorial header */}
      <div className="bg-white border-b border-border sticky top-16 z-40">
        <div className="container py-3">
          <div className="flex items-center gap-4 mb-3">
            <Link href={`/app/${app.id}`}>
              <button className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors">
                <ArrowLeft className="w-4 h-4" />
                {lang === "ko" ? app.nameKo : app.nameEn}
              </button>
            </Link>
            <div className="flex items-center gap-2 ml-auto">
              <span className="text-sm font-medium text-foreground">
                {currentStep + 1} / {app.steps.length}
              </span>
            </div>
          </div>

          {/* Progress bar */}
          <div className="w-full bg-muted rounded-full h-2 overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-500"
              style={{
                width: `${((currentStep + (completedSteps.has(currentStep) ? 1 : 0)) / app.steps.length) * 100}%`,
                backgroundColor: category?.color,
              }}
            />
          </div>
        </div>
      </div>

      <div className="flex flex-1 container py-8 gap-8">
        {/* Step sidebar (desktop) */}
        <aside className="hidden lg:block w-64 shrink-0">
          <div className="sticky top-36">
            <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-4">
              {t("전체 단계", "All Steps")}
            </h3>
            <div className="space-y-2">
              {app.steps.map((s, idx) => {
                const isCompleted = completedSteps.has(idx);
                const isCurrent = idx === currentStep;
                return (
                  <button
                    key={s.id}
                    onClick={() => setCurrentStep(idx)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-all text-sm ${
                      isCurrent
                        ? "font-semibold"
                        : "text-muted-foreground hover:text-foreground hover:bg-muted"
                    }`}
                    style={isCurrent ? { backgroundColor: category?.bgColor, color: category?.color } : {}}
                  >
                    <div className="shrink-0">
                      {isCompleted ? (
                        <CheckCircle2 className="w-5 h-5" style={{ color: category?.color }} />
                      ) : (
                        <div
                          className={`w-5 h-5 rounded-full border-2 flex items-center justify-center text-xs font-bold ${
                            isCurrent ? "" : "border-muted-foreground/30"
                          }`}
                          style={isCurrent ? { borderColor: category?.color, color: category?.color } : {}}
                        >
                          {idx + 1}
                        </div>
                      )}
                    </div>
                    <span className="line-clamp-1">
                      {lang === "ko" ? s.titleKo : s.titleEn}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </aside>

        {/* Main content */}
        <main className="flex-1 max-w-2xl">
          {/* Step header */}
          <div className="flex items-center gap-3 mb-6">
            <div
              className="step-circle text-white"
              style={{ backgroundColor: category?.color }}
            >
              {step.id}
            </div>
            <div>
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">
                {t(`단계 ${step.id}`, `Step ${step.id}`)}
              </p>
              <h1 className="text-2xl font-extrabold text-foreground" style={{ fontFamily: 'Outfit, sans-serif' }}>
                {lang === "ko" ? step.titleKo : step.titleEn}
              </h1>
            </div>
          </div>

          {/* Step content card */}
          <div className="bg-white rounded-2xl border border-border p-6 md:p-8 mb-6 shadow-sm">
            {/* App icon context */}
            <div className="flex items-center gap-3 mb-6 pb-6 border-b border-border">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center text-xl"
                style={{ backgroundColor: category?.bgColor }}
              >
                {app.icon}
              </div>
              <div>
                <p className="font-semibold text-sm text-foreground">
                  {lang === "ko" ? app.nameKo : app.nameEn}
                </p>
                <p className="text-xs text-muted-foreground">
                  {lang === "ko" ? app.descriptionKo : app.descriptionEn}
                </p>
              </div>
            </div>

            {/* Description */}
            <div className="prose prose-sm max-w-none">
              <p className="text-foreground leading-relaxed text-base">
                {lang === "ko" ? step.descriptionKo : step.descriptionEn}
              </p>
            </div>

            {/* Tip */}
            {step.tip && (
              <div
                className="mt-6 flex items-start gap-3 p-4 rounded-xl"
                style={{ backgroundColor: category?.bgColor }}
              >
                <span className="text-xl shrink-0">💡</span>
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider mb-1" style={{ color: category?.color }}>
                    {t("팁", "Tip")}
                  </p>
                  <p className="text-sm" style={{ color: category?.color }}>
                    {lang === "ko" ? step.tip.ko : step.tip.en}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Mobile step indicators */}
          <div className="flex items-center justify-center gap-2 mb-6 lg:hidden">
            {app.steps.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentStep(idx)}
                className={`transition-all duration-200 rounded-full ${
                  idx === currentStep ? "w-6 h-2.5" : "w-2.5 h-2.5"
                }`}
                style={{
                  backgroundColor:
                    completedSteps.has(idx)
                      ? category?.color
                      : idx === currentStep
                      ? category?.color
                      : category?.color + "30",
                }}
              />
            ))}
          </div>

          {/* Navigation buttons */}
          <div className="flex items-center gap-4">
            <button
              onClick={handlePrev}
              disabled={currentStep === 0}
              className="flex items-center gap-2 px-5 py-3 rounded-xl border-2 font-semibold text-foreground hover:bg-muted transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              style={{ borderColor: category?.color + "40" }}
            >
              <ArrowLeft className="w-4 h-4" />
              {t("이전", "Previous")}
            </button>

            <button
              onClick={handleNext}
              className="flex-1 flex items-center justify-center gap-2 px-6 py-3 rounded-xl text-white font-bold text-base shadow-md hover:shadow-lg transition-all hover:-translate-y-0.5"
              style={{ backgroundColor: category?.color }}
            >
              {isLastStep ? (
                <>
                  <CheckCircle2 className="w-5 h-5" />
                  {t("완료!", "Complete!")}
                </>
              ) : (
                <>
                  {t("다음 단계", "Next Step")}
                  <ArrowRight className="w-5 h-5" />
                </>
              )}
            </button>
          </div>
        </main>
      </div>

      {/* Footer */}
      <footer className="border-t border-border py-6 bg-white mt-auto">
        <div className="container flex items-center justify-between">
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer">
              <div className="w-6 h-6 rounded-md bg-primary flex items-center justify-center">
                <span className="text-white font-bold text-xs" style={{ fontFamily: 'Outfit, sans-serif' }}>K</span>
              </div>
              <span className="font-bold text-sm text-foreground" style={{ fontFamily: 'Outfit, sans-serif' }}>K-Life Guide</span>
            </div>
          </Link>
          <p className="text-xs text-muted-foreground">
            {t("외국인을 위한 한국 생활 앱 가이드", "Korean App Guide for Foreigners")}
          </p>
        </div>
      </footer>
    </div>
  );
}
