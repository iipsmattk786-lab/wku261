// Seoul Metro Design - App Detail Page
// App overview, features, FAQ, and tutorial entry

import { useState } from "react";
import { Link, useParams } from "wouter";
import { ArrowLeft, ChevronDown, ChevronUp, Play, CheckCircle2, HelpCircle } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { getAppById, getCategoryById, getDifficultyLabel, getDifficultyColor } from "@/lib/appData";
import Navbar from "@/components/Navbar";

export default function AppDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { lang, t } = useLanguage();
  const app = getAppById(id);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  if (!app) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-20 text-center">
          <p className="text-muted-foreground">{t("앱 가이드를 찾을 수 없습니다.", "App guide not found.")}</p>
          <Link href="/">
            <button className="mt-4 text-primary hover:underline">{t("홈으로 돌아가기", "Go back home")}</button>
          </Link>
        </div>
      </div>
    );
  }

  const category = getCategoryById(app.categoryId);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* App Hero */}
      <section className="py-12" style={{ backgroundColor: category?.bgColor }}>
        <div className="container">
          {/* Breadcrumb */}
          <nav className="flex items-center gap-2 text-sm mb-6">
            <Link href="/">
              <span className="text-muted-foreground hover:text-foreground transition-colors cursor-pointer">
                {t("홈", "Home")}
              </span>
            </Link>
            <span className="text-muted-foreground">/</span>
            <Link href={`/category/${app.categoryId}`}>
              <span className="hover:text-foreground transition-colors cursor-pointer" style={{ color: category?.color }}>
                {lang === "ko" ? category?.nameKo : category?.nameEn}
              </span>
            </Link>
            <span className="text-muted-foreground">/</span>
            <span className="text-foreground font-medium">
              {lang === "ko" ? app.nameKo : app.nameEn}
            </span>
          </nav>

          <div className="flex flex-col md:flex-row md:items-center gap-6">
            {/* App icon */}
            <div
              className="w-20 h-20 rounded-3xl flex items-center justify-center text-4xl shadow-lg shrink-0"
              style={{ backgroundColor: category?.color }}
            >
              {app.icon}
            </div>

            <div className="flex-1">
              <div className="flex flex-wrap items-center gap-3 mb-2">
                <h1 className="text-4xl font-extrabold text-foreground" style={{ fontFamily: 'Outfit, sans-serif' }}>
                  {lang === "ko" ? app.nameKo : app.nameEn}
                </h1>
                <span className={`text-sm font-semibold px-3 py-1 rounded-full ${getDifficultyColor(app.difficulty)}`}>
                  {getDifficultyLabel(app.difficulty, lang)}
                </span>
              </div>
              <p className="text-muted-foreground text-lg mb-4">
                {lang === "ko" ? app.descriptionKo : app.descriptionEn}
              </p>

              {/* Features */}
              <div className="flex flex-wrap gap-2">
                {app.features.map((f, i) => (
                  <span
                    key={i}
                    className="flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-full font-medium"
                    style={{ backgroundColor: "white", color: category?.color, border: `1px solid ${category?.color}40` }}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    {lang === "ko" ? f.ko : f.en}
                  </span>
                ))}
              </div>
            </div>

            {/* CTA */}
            <div className="shrink-0">
              <Link href={`/app/${app.id}/tutorial`}>
                <button
                  className="flex items-center gap-3 px-8 py-4 rounded-2xl text-white font-bold text-lg shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5"
                  style={{ backgroundColor: category?.color }}
                >
                  <Play className="w-5 h-5 fill-white" />
                  {t("튜토리얼 시작", "Start Tutorial")}
                </button>
              </Link>
              <p className="text-xs text-muted-foreground text-center mt-2">
                {app.steps.length} {t("단계", "steps")}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Steps Overview */}
      <section className="container py-12">
        <h2 className="text-2xl font-extrabold text-foreground mb-6" style={{ fontFamily: 'Outfit, sans-serif' }}>
          {t("학습 단계", "Learning Steps")}
        </h2>

        <div className="relative">
          {/* Vertical line */}
          <div
            className="absolute left-[18px] top-0 bottom-0 w-0.5"
            style={{ backgroundColor: category?.color + "30" }}
          />

          <div className="space-y-4">
            {app.steps.map((step, idx) => (
              <div key={step.id} className="flex gap-4 pl-0">
                {/* Step circle */}
                <div
                  className="step-circle text-white shrink-0 relative z-10"
                  style={{ backgroundColor: idx === 0 ? category?.color : category?.color + "60" }}
                >
                  {step.id}
                </div>

                <div className="flex-1 bg-white rounded-xl border border-border p-5 card-lift">
                  <h3 className="font-bold text-foreground mb-1" style={{ fontFamily: 'Outfit, sans-serif' }}>
                    {lang === "ko" ? step.titleKo : step.titleEn}
                  </h3>
                  <p className="text-sm text-muted-foreground line-clamp-2">
                    {lang === "ko" ? step.descriptionKo : step.descriptionEn}
                  </p>
                  {step.tip && (
                    <div
                      className="mt-3 flex items-start gap-2 text-xs p-2.5 rounded-lg"
                      style={{ backgroundColor: category?.bgColor, color: category?.color }}
                    >
                      <span className="font-bold shrink-0">💡 Tip</span>
                      <span>{lang === "ko" ? step.tip.ko : step.tip.en}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Start tutorial CTA */}
        <div className="mt-8 text-center">
          <Link href={`/app/${app.id}/tutorial`}>
            <button
              className="inline-flex items-center gap-3 px-10 py-4 rounded-2xl text-white font-bold text-lg shadow-lg hover:shadow-xl transition-all hover:-translate-y-0.5"
              style={{ backgroundColor: category?.color }}
            >
              <Play className="w-5 h-5 fill-white" />
              {t("단계별 튜토리얼 시작하기", "Start Step-by-Step Tutorial")}
            </button>
          </Link>
        </div>
      </section>

      {/* FAQ Section */}
      {app.faqs.length > 0 && (
        <section className="py-12 bg-muted/40">
          <div className="container">
            <div className="flex items-center gap-3 mb-8">
              <HelpCircle className="w-6 h-6" style={{ color: category?.color }} />
              <h2 className="text-2xl font-extrabold text-foreground" style={{ fontFamily: 'Outfit, sans-serif' }}>
                {t("자주 묻는 질문", "Frequently Asked Questions")}
              </h2>
            </div>

            <div className="space-y-3 max-w-3xl">
              {app.faqs.map((faq, idx) => (
                <div key={idx} className="bg-white rounded-xl border border-border overflow-hidden">
                  <button
                    onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                    className="w-full flex items-center justify-between p-5 text-left hover:bg-muted/30 transition-colors"
                  >
                    <span className="font-semibold text-foreground pr-4">
                      {lang === "ko" ? faq.questionKo : faq.questionEn}
                    </span>
                    {openFaq === idx ? (
                      <ChevronUp className="w-5 h-5 text-muted-foreground shrink-0" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-muted-foreground shrink-0" />
                    )}
                  </button>
                  {openFaq === idx && (
                    <div
                      className="px-5 pb-5 text-sm text-muted-foreground leading-relaxed border-t border-border pt-4"
                      style={{ borderColor: category?.color + "20" }}
                    >
                      {lang === "ko" ? faq.answerKo : faq.answerEn}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Footer */}
      <footer className="border-t border-border py-8 bg-white">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4">
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer">
              <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center">
                <span className="text-white font-bold text-xs" style={{ fontFamily: 'Outfit, sans-serif' }}>K</span>
              </div>
              <span className="font-bold text-foreground" style={{ fontFamily: 'Outfit, sans-serif' }}>K-Life Guide</span>
            </div>
          </Link>
          <p className="text-sm text-muted-foreground">
            {t("외국인을 위한 한국 생활 앱 가이드", "Korean App Guide for Foreigners")}
          </p>
        </div>
      </footer>
    </div>
  );
}
