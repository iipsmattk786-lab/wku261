// Seoul Metro Design - Home Page
// Hero section + Category cards + Featured apps

import { useState } from "react";
import { Link } from "wouter";
import { ArrowRight, Search, BookOpen, Globe, Zap, ChevronRight } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { categories, appGuides, searchApps, getDifficultyLabel, getDifficultyColor } from "@/lib/appData";
import Navbar from "@/components/Navbar";

export default function Home() {
  const { lang, t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState("");
  const searchResults = searchQuery.length > 1 ? searchApps(searchQuery) : [];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url(https://d2xsxph8kpxj0f.cloudfront.net/310519663670945450/LSqMnGR6udQiFU7R9ESGnE/hero-banner-X8JJRowjPwxzwnpnfVoMU5.webp)`,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900/85 via-slate-900/60 to-slate-900/30" />

        <div className="relative container py-20 md:py-28">
          <div className="max-w-2xl">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-white/15 backdrop-blur-sm border border-white/25 rounded-full px-4 py-1.5 mb-6">
              <Globe className="w-3.5 h-3.5 text-yellow-300" />
              <span className="text-white/90 text-xs font-medium" style={{ fontFamily: 'Outfit, sans-serif' }}>
                {t("한국어 · English", "한국어 · English")}
              </span>
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-white leading-tight mb-4" style={{ fontFamily: 'Outfit, sans-serif' }}>
              {lang === "ko" ? (
                <>한국 앱,<br /><span className="text-yellow-300">이제 쉽게</span> 쓰세요</>
              ) : (
                <>Korean Apps,<br /><span className="text-yellow-300">Made Simple</span></>
              )}
            </h1>

            <p className="text-lg text-white/80 mb-8 leading-relaxed max-w-lg">
              {t(
                "당근마켓, 쿠팡, 배달의민족 등 한국 생활 필수 앱 사용법을 단계별로 안내합니다.",
                "Step-by-step guides for Karrot, Coupang, Baemin, and other essential Korean apps."
              )}
            </p>

            {/* Hero search */}
            <div className="relative max-w-md">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input
                  type="text"
                  placeholder={t("앱 이름으로 검색...", "Search for an app...")}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 text-base bg-white rounded-xl shadow-lg border-0 focus:outline-none focus:ring-2 focus:ring-primary/40 text-foreground placeholder:text-slate-400"
                />
              </div>
              {searchResults.length > 0 && (
                <div className="absolute top-full mt-2 w-full bg-white rounded-xl border border-border shadow-xl z-50 overflow-hidden">
                  {searchResults.map((app) => (
                    <Link key={app.id} href={`/app/${app.id}`}>
                      <div
                        className="flex items-center gap-3 px-4 py-3 hover:bg-muted transition-colors cursor-pointer"
                        onClick={() => setSearchQuery("")}
                      >
                        <span className="text-2xl">{app.icon}</span>
                        <div>
                          <p className="font-semibold text-sm text-foreground">
                            {lang === "ko" ? app.nameKo : app.nameEn}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {lang === "ko" ? app.descriptionKo : app.descriptionEn}
                          </p>
                        </div>
                        <ChevronRight className="w-4 h-4 text-muted-foreground ml-auto" />
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </div>

            {/* Stats */}
            <div className="flex items-center gap-6 mt-8">
              {[
                { num: "8+", label: t("앱 가이드", "App Guides") },
                { num: "3", label: t("카테고리", "Categories") },
                { num: "2", label: t("언어 지원", "Languages") },
              ].map((stat) => (
                <div key={stat.label} className="text-center">
                  <p className="text-2xl font-extrabold text-white" style={{ fontFamily: 'Outfit, sans-serif' }}>{stat.num}</p>
                  <p className="text-xs text-white/60">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Features strip */}
      <section className="bg-primary py-4">
        <div className="container">
          <div className="flex flex-wrap items-center justify-center gap-6 md:gap-12">
            {[
              { icon: <BookOpen className="w-4 h-4" />, label: t("단계별 튜토리얼", "Step-by-step tutorials") },
              { icon: <Globe className="w-4 h-4" />, label: t("한국어 · 영어", "Korean · English") },
              { icon: <Zap className="w-4 h-4" />, label: t("시각적 가이드", "Visual guides") },
              { icon: <Search className="w-4 h-4" />, label: t("빠른 검색", "Quick search") },
            ].map((f) => (
              <div key={f.label} className="flex items-center gap-2 text-white/90">
                {f.icon}
                <span className="text-sm font-medium">{f.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 container">
        <div className="mb-10">
          <h2 className="text-3xl font-extrabold text-foreground mb-2" style={{ fontFamily: 'Outfit, sans-serif' }}>
            {t("카테고리", "Categories")}
          </h2>
          <p className="text-muted-foreground">
            {t("원하는 카테고리를 선택하세요", "Choose a category to get started")}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {categories.map((cat, idx) => (
            <Link key={cat.id} href={`/category/${cat.id}`}>
              <div
                className="group relative overflow-hidden rounded-2xl border border-border card-lift cursor-pointer"
                style={{ animationDelay: `${idx * 60}ms` }}
              >
                {/* Category image */}
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={cat.image}
                    alt={lang === "ko" ? cat.nameKo : cat.nameEn}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div
                    className="absolute inset-0"
                    style={{ background: `linear-gradient(to top, ${cat.color}CC 0%, transparent 60%)` }}
                  />
                  <div className="absolute bottom-4 left-4">
                    <span className="text-3xl">{cat.icon}</span>
                  </div>
                </div>

                {/* Category info */}
                <div className="p-5" style={{ backgroundColor: cat.bgColor }}>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-xl font-bold text-foreground" style={{ fontFamily: 'Outfit, sans-serif' }}>
                      {lang === "ko" ? cat.nameKo : cat.nameEn}
                    </h3>
                    <span
                      className="text-xs font-semibold px-2.5 py-1 rounded-full text-white"
                      style={{ backgroundColor: cat.color }}
                    >
                      {cat.apps.length} {t("앱", "apps")}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">
                    {lang === "ko" ? cat.descriptionKo : cat.descriptionEn}
                  </p>
                  <div className="flex items-center gap-1 text-sm font-semibold" style={{ color: cat.color }}>
                    {t("가이드 보기", "View guides")}
                    <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* All Apps Section */}
      <section className="py-16 bg-muted/40">
        <div className="container">
          <div className="mb-10">
            <h2 className="text-3xl font-extrabold text-foreground mb-2" style={{ fontFamily: 'Outfit, sans-serif' }}>
              {t("모든 앱 가이드", "All App Guides")}
            </h2>
            <p className="text-muted-foreground">
              {t("원하는 앱을 선택하여 사용법을 확인하세요", "Select an app to learn how to use it")}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {appGuides.map((app, idx) => {
              const cat = categories.find((c) => c.id === app.categoryId);
              return (
                <Link key={app.id} href={`/app/${app.id}`}>
                  <div
                    className="bg-white rounded-xl border border-border p-5 card-lift cursor-pointer"
                    style={{ animationDelay: `${idx * 40}ms` }}
                  >
                    <div className="flex items-start gap-3 mb-3">
                      <div
                        className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl shrink-0"
                        style={{ backgroundColor: cat?.bgColor }}
                      >
                        {app.icon}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold text-foreground truncate" style={{ fontFamily: 'Outfit, sans-serif' }}>
                          {lang === "ko" ? app.nameKo : app.nameEn}
                        </h3>
                        <span
                          className="text-xs font-medium px-2 py-0.5 rounded-full"
                          style={{ backgroundColor: cat?.bgColor, color: cat?.color }}
                        >
                          {lang === "ko" ? cat?.nameKo : cat?.nameEn}
                        </span>
                      </div>
                    </div>

                    <p className="text-xs text-muted-foreground mb-3 line-clamp-2">
                      {lang === "ko" ? app.descriptionKo : app.descriptionEn}
                    </p>

                    <div className="flex items-center justify-between">
                      <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${getDifficultyColor(app.difficulty)}`}>
                        {getDifficultyLabel(app.difficulty, lang)}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {app.steps.length} {t("단계", "steps")}
                      </span>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* FAQ Preview / CTA */}
      <section className="py-16 container">
        <div className="bg-primary rounded-2xl p-8 md:p-12 text-white text-center">
          <h2 className="text-3xl font-extrabold mb-3" style={{ fontFamily: 'Outfit, sans-serif' }}>
            {t("한국 생활, 이제 어렵지 않아요", "Korean Life, No Longer Difficult")}
          </h2>
          <p className="text-white/80 mb-8 max-w-xl mx-auto">
            {t(
              "단계별 가이드를 따라하면 누구든 한국 앱을 쉽게 사용할 수 있습니다.",
              "Follow our step-by-step guides and anyone can use Korean apps with ease."
            )}
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            {categories.map((cat) => (
              <Link key={cat.id} href={`/category/${cat.id}`}>
                <button className="flex items-center gap-2 bg-white/15 hover:bg-white/25 border border-white/25 text-white px-5 py-2.5 rounded-xl font-medium transition-all">
                  <span>{cat.icon}</span>
                  <span>{lang === "ko" ? cat.nameKo : cat.nameEn}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 bg-white">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center">
              <span className="text-white font-bold text-xs" style={{ fontFamily: 'Outfit, sans-serif' }}>K</span>
            </div>
            <span className="font-bold text-foreground" style={{ fontFamily: 'Outfit, sans-serif' }}>K-Life Guide</span>
          </div>
          <p className="text-sm text-muted-foreground text-center">
            {t(
              "외국인을 위한 한국 생활 앱 가이드",
              "Korean App Guide for Foreigners"
            )}
          </p>
          <p className="text-xs text-muted-foreground">
            {t("한국어 · English", "한국어 · English")}
          </p>
        </div>
      </footer>
    </div>
  );
}
