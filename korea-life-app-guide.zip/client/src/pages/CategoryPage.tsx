// Seoul Metro Design - Category Page
// Shows all apps within a category

import { Link, useParams } from "wouter";
import { ArrowLeft, ChevronRight } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { getCategoryById, getAppsByCategory, getDifficultyLabel, getDifficultyColor } from "@/lib/appData";
import Navbar from "@/components/Navbar";

export default function CategoryPage() {
  const { id } = useParams<{ id: string }>();
  const { lang, t } = useLanguage();
  const category = getCategoryById(id);
  const apps = getAppsByCategory(id);

  if (!category) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-20 text-center">
          <p className="text-muted-foreground">{t("카테고리를 찾을 수 없습니다.", "Category not found.")}</p>
          <Link href="/">
            <button className="mt-4 text-primary hover:underline">{t("홈으로 돌아가기", "Go back home")}</button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Category Hero */}
      <section
        className="relative py-14 overflow-hidden"
        style={{ backgroundColor: category.bgColor }}
      >
        {/* Background image */}
        <div
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{ backgroundImage: `url(${category.image})` }}
        />
        <div className="relative container">
          <Link href="/">
            <button className="flex items-center gap-2 text-sm font-medium mb-6 hover:opacity-70 transition-opacity" style={{ color: category.color }}>
              <ArrowLeft className="w-4 h-4" />
              {t("홈으로", "Back to Home")}
            </button>
          </Link>

          <div className="flex items-center gap-4 mb-4">
            <div
              className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl shadow-md"
              style={{ backgroundColor: category.color }}
            >
              <span className="text-3xl">{category.icon}</span>
            </div>
            <div>
              <h1 className="text-4xl font-extrabold text-foreground" style={{ fontFamily: 'Outfit, sans-serif' }}>
                {lang === "ko" ? category.nameKo : category.nameEn}
              </h1>
              <p className="text-muted-foreground mt-1">
                {lang === "ko" ? category.descriptionKo : category.descriptionEn}
              </p>
            </div>
          </div>

          <div
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold text-white"
            style={{ backgroundColor: category.color }}
          >
            {apps.length} {t("개 앱 가이드", "app guides available")}
          </div>
        </div>
      </section>

      {/* Apps List */}
      <section className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {apps.map((app, idx) => (
            <Link key={app.id} href={`/app/${app.id}`}>
              <div
                className="bg-white rounded-2xl border border-border overflow-hidden card-lift cursor-pointer"
                style={{ animationDelay: `${idx * 80}ms` }}
              >
                {/* App header */}
                <div className="p-6 pb-4">
                  <div className="flex items-start gap-4 mb-4">
                    <div
                      className="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl shrink-0 shadow-sm"
                      style={{ backgroundColor: category.bgColor }}
                    >
                      {app.icon}
                    </div>
                    <div className="flex-1">
                      <h2 className="text-xl font-bold text-foreground" style={{ fontFamily: 'Outfit, sans-serif' }}>
                        {lang === "ko" ? app.nameKo : app.nameEn}
                      </h2>
                      <p className="text-sm text-muted-foreground mt-0.5">
                        {lang === "ko" ? app.descriptionKo : app.descriptionEn}
                      </p>
                    </div>
                  </div>

                  {/* Features */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    {app.features.slice(0, 3).map((f, i) => (
                      <span
                        key={i}
                        className="text-xs px-2.5 py-1 rounded-full font-medium"
                        style={{ backgroundColor: category.bgColor, color: category.color }}
                      >
                        {lang === "ko" ? f.ko : f.en}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Footer */}
                <div className="px-6 py-4 border-t border-border flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${getDifficultyColor(app.difficulty)}`}>
                      {getDifficultyLabel(app.difficulty, lang)}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {app.steps.length} {t("단계", "steps")}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 text-sm font-semibold" style={{ color: category.color }}>
                    {t("가이드 보기", "View guide")}
                    <ChevronRight className="w-4 h-4" />
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 bg-white mt-8">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4">
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer">
              <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center">
                <span className="text-white font-bold text-xs" style={{ fontFamily: 'Outfit, sans-serif' }}>K</span>
              </div>
              <span className="font-bold text-foreground" style={{ fontFamily: 'Outfit, sans-serif' }}>K-Life Guide</span>
            </div>
          </Link>
          <p className="text-sm text-muted-foreground">
            {t("외국인을 위한 한국 생활 앱 가이드", "Korean App Guide for Foreigners")}
          </p>
        </div>
      </footer>
    </div>
  );
}
