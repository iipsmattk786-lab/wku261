// Seoul Metro Design - Navbar Component
// Sticky top navigation with language switcher and search

import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Search, X, Menu } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { searchApps } from "@/lib/appData";
import { Button } from "@/components/ui/button";

export default function Navbar() {
  const { lang, setLang, t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [, navigate] = useLocation();

  const searchResults = searchQuery.length > 1 ? searchApps(searchQuery) : [];

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-border shadow-sm">
      <div className="container">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 shrink-0">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <span className="text-white font-bold text-sm" style={{ fontFamily: 'Outfit, sans-serif' }}>K</span>
            </div>
            <div className="hidden sm:block">
              <span className="font-bold text-foreground text-lg leading-none" style={{ fontFamily: 'Outfit, sans-serif' }}>
                K-Life Guide
              </span>
              <p className="text-xs text-muted-foreground leading-none mt-0.5">
                {t("한국 앱 사용 가이드", "Korean App Guide")}
              </p>
            </div>
          </Link>

          {/* Search bar (desktop) */}
          <div className="hidden md:flex flex-1 max-w-md relative">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="text"
                placeholder={t("앱 이름으로 검색...", "Search apps...")}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 text-sm bg-muted rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
            {/* Search dropdown */}
            {searchResults.length > 0 && (
              <div className="absolute top-full mt-1 w-full bg-white rounded-lg border border-border shadow-lg z-50 overflow-hidden">
                {searchResults.map((app) => (
                  <button
                    key={app.id}
                    onClick={() => {
                      navigate(`/app/${app.id}`);
                      setSearchQuery("");
                    }}
                    className="w-full flex items-center gap-3 px-4 py-3 hover:bg-muted text-left transition-colors"
                  >
                    <span className="text-xl">{app.icon}</span>
                    <div>
                      <p className="font-medium text-sm text-foreground">
                        {lang === "ko" ? app.nameKo : app.nameEn}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {lang === "ko" ? app.descriptionKo : app.descriptionEn}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right side controls */}
          <div className="flex items-center gap-2">
            {/* Mobile search toggle */}
            <button
              className="md:hidden p-2 rounded-lg hover:bg-muted transition-colors"
              onClick={() => setShowSearch(!showSearch)}
            >
              <Search className="w-5 h-5 text-foreground" />
            </button>

            {/* Language switcher */}
            <div className="flex items-center bg-muted rounded-lg p-1 gap-1">
              <button
                onClick={() => setLang("en")}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all duration-200 ${
                  lang === "en"
                    ? "bg-white text-primary shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                }`}
                style={{ fontFamily: 'Outfit, sans-serif' }}
              >
                EN
              </button>
              <button
                onClick={() => setLang("ko")}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all duration-200 ${
                  lang === "ko"
                    ? "bg-white text-primary shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                }`}
                style={{ fontFamily: 'Noto Sans KR, sans-serif' }}
              >
                한국어
              </button>
            </div>
          </div>
        </div>

        {/* Mobile search bar */}
        {showSearch && (
          <div className="md:hidden pb-3 relative">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="text"
                placeholder={t("앱 이름으로 검색...", "Search apps...")}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                autoFocus
                className="w-full pl-9 pr-4 py-2 text-sm bg-muted rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all"
              />
            </div>
            {searchResults.length > 0 && (
              <div className="absolute left-0 right-0 top-full bg-white rounded-lg border border-border shadow-lg z-50 overflow-hidden mx-4">
                {searchResults.map((app) => (
                  <button
                    key={app.id}
                    onClick={() => {
                      navigate(`/app/${app.id}`);
                      setSearchQuery("");
                      setShowSearch(false);
                    }}
                    className="w-full flex items-center gap-3 px-4 py-3 hover:bg-muted text-left transition-colors"
                  >
                    <span className="text-xl">{app.icon}</span>
                    <div>
                      <p className="font-medium text-sm text-foreground">
                        {lang === "ko" ? app.nameKo : app.nameEn}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </header>
  );
}
